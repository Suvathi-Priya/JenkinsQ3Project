package testCase;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Assert;
import Pages.loginPage;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

@Test
public class loginPageTestCases {

    WebDriver driver;
    loginPage logPage;
    ExtentReports extentreports;
    ExtentTest test;

    @BeforeMethod
    public void setUp() {
        // Initialize WebDriver
        driver = new ChromeDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

        // Create an instance of the loginPage
        logPage = new loginPage(driver);

        // Setup Extent Report
        ExtentSparkReporter htmlReporter = new ExtentSparkReporter("./ExtentReports/searchExtentReport.html");
        extentreports = new ExtentReports();
        extentreports.attachReporter(htmlReporter);
        test = extentreports.createTest("SearchTest");
    }

    @Test
	public void testLogin() {
        // Start the test in Extent Reports
        test = extentreports.createTest("Test Login");

        try {
            // Test case for login
            String user_name = "Admin";
            String pass_word = "admin123";
            logPage.doLogin(user_name, pass_word);

            test.pass("Login Test passed");
        } catch (Exception e) {
            Assert.fail("Login Test failed: " + e.getMessage());
        }
    }

    @AfterMethod
    public void tearDown() {
        // Close the WebDriver
        if (driver != null) {
            driver.quit();
        }

        // Flush the Extent report to save the results
        extentreports.flush();
    }
}
